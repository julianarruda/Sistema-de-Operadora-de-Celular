#include "Cliente.h"

Cliente::Cliente(){
}
Cliente::Cliente(string nome, string CPF_CNPJ, string endereco){ //M�todo para inserir o pais e a Data de Cadastro do cliente.
    _nome = nome;
    _CPF_CNPJ = CPF_CNPJ;
    _endereco = endereco;
}
Cliente::~Cliente(){
}
string Cliente::get_nome(){
    return this->_nome;
}

string Cliente::get_CPF(){
    return this->_CPF_CNPJ;
}

string Cliente::get_endereco(){
    return this->_endereco;
}

string Cliente::Dados_Cliente(){
        cout<<"             Cadastrar Cliente"<<endl;
        cout<<"Nome do cliente: "<<endl;
        cin>>_nome;
        cout<<"Endere�o: "<<endl;
        cin>>_endereco;
        cout<<"CPF ou CNPJ: "<<endl;

        cin>>_CPF_CNPJ;
        cout<<endl;
        cout<<"Nome do cliente: "<< _nome<<endl;
        cout<<"Endere�o: "<< _endereco<<endl;
        cout<<"CPF/CNPJ: "<< _CPF_CNPJ<<endl;

}

void Cliente::Ver_Dados(){
    cout<<"Nome do cliente: "<< _nome<<endl;
    cout<<"Endere�o: "<< _endereco<<endl;
    cout<<"CPF/CNPJ: "<< _CPF_CNPJ<<endl;
    cout<<"Pais do cliente: "<< _Pais<<endl;
    cout<<"Data do Cadastro: "<< _Data<<endl;
}

