#ifndef _CELULAR_H
#define _CELULAR_H

#include <string>
#include <iostream>
#include "Date.h"
#include <ctime>
#include <vector>
#include "Plano.h"
#include "Liga��o.h"
#include <vector>

using namespace std;

class Celular{
private:
    double _numero; //Vari�vel para o numero do cliente.
    Plano _plano;
    vector <Ligacao>_ligacoes;
    static double proxNumCelular;
public:
    Celular();
    Celular(double numero, Plano plano, static double proxNumCelular);
    ~Celular();
    double get_numero();
    void set_numero();
    void set_cliente();
    void set_plano();
    static proxNumCelular();
};
#endif // _CELULAR_H
