#include "Plano.h"
#include "time.h"

Plano::Plano(){
}

Plano::Plano(string nomePlano, double ValorMin, double Velocidade, double franquia, double VelocAlem){
    _nomePlano = nomePlano;
    _ValorMin = ValorMin;
    _Velocidade = Velocidade;
    _Franquia = franquia;
    _VelocAlem = VelocAlem;
}
Plano:: ~Plano(){
    cout<< "deletando Plano" << endl;
}
string Plano::set_NomeDoPlano(){
        int t;
        cout<< "Escolha o tipo do plano: (1)PrePago e (2)Pospago"<<endl;
        cin>>t;
        if(t==1){
            int i;
            string p[3] = {"PrePago Controle","PrePago Standart", "PrePago Turbo"};
            cout<<"Planos Disponiveis: "<<endl;
            cout<<"(0)PrePago Controle";
            cout<<"(1)PrePago Standart";
            cout<<"(2)PrePago Turbo"<<endl;
            cout<<"Escolha uma das tres opcoes: "<<endl;
            cin>>i;
            _nomePlano = p[i];
            cout<<"O plano cadastrado para esse cliente e: "<<_nomePlano<<endl;
        }
        else if(t==2){
            int i;
            string po[3] = {"PosPago Controle","PosPago Premium", "PosPago Mega"};
            cout<<"Planos disponiveis: "<<endl;
            cout<< "(0)PosPago Controle"<<endl;
            cout<< "(1)PosPago Premium"<<endl;
            cout<< "(2)PossPago Mega"<<endl;
            cout<<"Escolha uma das tres opcoes: "<<endl;
            cin>>i;
            _nomePlano = po[i];
            cout<<"O plano cadastrado para esse cliente e: "<<_nomePlano<<endl;
        }
        else
            cout<<"Tipo de plano indisponivel"<<endl;
}

double Plano::set_ValoresDoPlano(){
    cout<<"Valores do Plano selecionado"<<endl;
    cout<< "Insira o valor a ser cobrado por liga��o:"<<endl;
    cin>> _ValorMin;
    cout<<"Insira a velocidade associada ao plano: "<<endl;
    cin>> _Velocidade;
    cout<<"Insira o tipo de franquia: "<<endl;
    cin>> _Franquia;
    cout<<"Insira a velocidade al�m da franquia: "<<endl;
    cin>> _VelocAlem;
    cout<<"Os valores do plano sao: "<<endl;
    cout<<"Valor do minuto: "<<_ValorMin<<endl;
    cout<<"Velocidade: "<< _Velocidade<<endl;
    cout<<"Franquia: "<< _Franquia<<endl;
    cout<<"Velocidade Alem da Franquia: "<< _VelocAlem<<endl;

}


PrePago:: PrePago (){
    cout<< "digite o nome do plano: "<< nomePlano<< endl;
    _nomePlano= cin>> nomePlano;
    _credito= 10;
    Date vali;
    vali::set_localdate();
    set_ValoresDoPlano();
}

PrePago:: PrePago (string nomePlano, double credito = 10){
    _nomePlano = nomePlano;
    _credito   = credito;
    Date vali;
    vali::set_localdate();
    vali::mes += 2;       //Validade do plano come�ando no mes atual +2 meses (real validade)
    set_ValoresDoPlano();
}
string PrePago::set_NomeDoPlano(){
    cout<<"Qual o nome do plano PrePago: "<< endl;
    cin>>_nomePlano;
    cout<<"Nome do Plano: "<< _nomePlano<< endl;
}
PrePago:: ~PrePago(){
    cout<< "deletando Plano PrePago" << endl;
}
void PrePago::add_credito(int numero_celular, int valor){
    celular.v+=valor;
    time_t tempo = time(NULL);
    time_t rawtime;
    struct tm *info;
    time( &rawtime );
    info = localtime( &rawtime );
    _validade->mes = (*info.tm_mon + 6);
}
double PrePago:: get_credito(int numero_celular){
    return numero_celular.credito;
}
string PrePago:: get_validade(int numero_celular){
    return numero_celular.validade;
}
PosPago::PosPago(string _nomePlano,Date vencimento){
    _nomePlano= nomePlano;
    _Vencimento= vencimento;
    PosPago::set_ValoresDoPlano();
}
PosPago:: ~PosPago(){
    cout<< "deletando Plano PosPago" << endl;
}
string PosPago::set_NomeDoPlano(){
    cout<<"Qual o nome do plano PosPago: "<< endl;
    cin>>_nomePlano;
    cout<<"Nome do Plano: "<< _nomePlano<< endl;
}
Date PosPago::get_vencimento(){
    return this ->_vencimento->mes;
}

