#ifndef _DATE_H
#define _DATE_H

#include <iostream>
using namespace std;

class Date{
public:
    unsigned int dia;
    unsigned int mes;
    unsigned int ano;
    unsigned int hora;
    unsigned int minuts;

    Date();
    Date(unsigned int _dia, unsigned int _mes, unsigned int _ano, unsigned int _hora, unsigned int _minuts);
    ~Date();
    void diadomes(unsigned int _dia);
    unsigned int get_diadomes();
    char* set_datalocal();
    void set_localdate();
};
#endif // _DATE_H

