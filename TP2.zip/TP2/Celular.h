#ifndef _CELULAR_H
#define _CELULAR_H

#include <string>
#include <iostream>
#include <vector>
#include "Cliente.h"
#include "Plano.h"

using namespace std;

template <typename Ligacao>

class Celular{
private:
    double _numero;
    Plano _plano;
    vector<Ligacao>_ligacoes;
    static double _proxNumCelular;
public:
    Celular();
    ~Celular();
    Celular(double numero, Plano plano, double proxNumCelular);
    double get_numero();
    Plano get_plano();
    static double get_proxNum();
    double NovoCelular();
};
#endif // _CELULAR_H



