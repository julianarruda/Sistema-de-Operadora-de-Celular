#include <iostream>
#include <ctime>
#include "Cliente.h"
#include "Celular.h"
#include "Plano.h"
#include "Liga��o.h"
#include "Date.h"

using namespace std;

int main()
{
    time_t now = time(0);
    char* dt = ctime(&now);
    cout << dt << endl;

    return 0;
}
