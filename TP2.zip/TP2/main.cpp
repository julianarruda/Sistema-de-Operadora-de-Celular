#include "Cliente.h"
#include "Celular.h"
#include "Plano.h"
#include "Liga��o.h"

#include <iostream>
#include <string>
using namespace std;

int main(){
    Cliente C1, C2;
    Celular Cel;
    Plano P;
    PrePago Pre;
    PosPago Pos;
    Ligacao L;
    LigacaoSimples LS;
    LigacaoDados LD;
    C1.Dados_Cliente();
    C2.Ver_Dados();
    Cel.NovoCelular();
    P1.set_NomeDoPlano();
    P2.set_ValoresDoPlano();
    L.registro_ligacao();
 return 0;
}
