#include "Plano.h"
#include "time.h"

Plano::Plano(){
}

Plano::Plano(string nomePlano){
    _nomePlano = nomePlano;
    Plano::set_ValoresDoPlano();
}
Plano:: ~Plano(){
    cout<< "deletando Plano" << endl;
}
string Plano::set_NomeDoPlano(){
    int t;
    cout<< "Escolha o tipo do plano: (1)Pre-Pago e (2)Pos-pago"<<endl;
    if(t=1){
        cout<<"Planos disponiveis: "<<endl;
        cout<< "*Pre-Pago Controle"<<endl;
        cout<< "*Pre-Pago Standart"<<endl;
        cout<< "*Pre-Pago Turbo"<<endl;
        cin>>_nomePlano;
        cout<<"O plano cadastrado para esse cliente e: "<<_nomePlano<<endl;
    }
    else if(t=2){
        cout<<"Planos disponiveis: "<<endl;
        cout<< "*Pos-Pago Controle"<<endl;
        cout<< "*Pos-Pago Premium"<<endl;
        cout<< "*Pos-Pago Controle"<<endl;
        cin>>_nomePlano;
        cout<<"O plano cadastrado para esse cliente e: "<<_nomePlano<<endl;
    }
    else
        cout<<"Tipo de plano indispon�vel"<<endl;
}

void Plano::set_ValoresDoPlano(){
    cout<< "Insira o valor a ser cobrado por liga��o:";
    cin>> _ValorMin;
    cout<<"Insira a velocidade associada ao plano: ";
    cin>> _Velocidade;
    cout<<"Insira o tipo de franquia: ";
    cin>> _franquia;
    cout<<"Insira a velocidade al�m da franquia: ";
    cin>> _VelocAlem;
};


PrePago:: PrePago (){
    cout<< "digite o nome do plano: "<< nomePlano<< endl;
    _nomePlano= cin>> nomePlano;
    _credito= 10;
    Date vali;
    vali::set_localdate();
    set_ValoresDoPlano();
}

PrePago:: PrePago (string nomePlano, double credito = 10){
    _nomePlano= nomePlano;
    _credito= credito;
    Date vali;
    vali::set_localdate();
    vali::mes += 2;       //Validade do plano come�ando no mes atual +2 meses (real validade)

    set_ValoresDoPlano();
}
string PrePago::set_NomeDoPlano(){
    cout<<"Qual o nome do plano Pre-Pago: "<< endl;
    cin>>_nomePlano;
    cout<<"Nome do Plano: "<< _nomePlano<< endl;
}
PrePago:: ~PrePago(){
    cout<< "deletando Plano PrePago" << endl;
}
void PrePago::add_credito(int numero_celular, int valor){
    celular.v+=valor;
    time_t tempo = time(NULL);
    time_t rawtime;
    struct tm *info;
    time( &rawtime );
    info = localtime( &rawtime );
    _validade->mes = (*info.tm_mon + 6);
}
double PrePago:: get_credito(int numero_celular){
    return numero_celular.credito;
}
string PrePago:: get_validade(int numero_celular){
    return numero_celular.validade;
}
PosPago::PosPago(string _nomePlano,Date vencimento){
    _nomePlano= nomePlano;
    _Vencimento= vencimento;
    PosPago::set_ValoresDoPlano();
}
PosPago:: ~PosPago(){
    cout<< "deletando Plano PosPago" << endl;
}
string PosPago::set_NomeDoPlano(){
    cout<<"Qual o nome do plano Pos-Pago: "<< endl;
    cin>>_nomePlano;
    cout<<"Nome do Plano: "<< _nomePlano<< endl;
}
Date PosPago::get_vencimento(){
    return this ->_vencimento->mes;
}
