#include "Celular.h"

Celular::Celular(){
}
Celular::~Celular(){
}
Celular::Celular(double numero, Plano plano, double proxNumCelular){
    _numero = numero;
    _plano = plano;
    _proxNumCelular = proxNumCelular;
}
double Celular::NovoCelular(vector<Celular>C){
    Cliente Cl
    Date V;
    Cl.DadosCliente();
    cout<<"(1) PosPago, (2) PrePago"<<endl;
    cin>>_plano;
    if(_plano=1){
        cout<<"Entre com a data de vencimento da conta: "<< endl;
        cin>>V;
        cout<<"A data de vencimento da conta e: "<<V<<endl;
    }
}-
