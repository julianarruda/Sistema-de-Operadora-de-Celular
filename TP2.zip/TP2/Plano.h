#ifndef _PLANO_H
#define _PLANO_H

#include <string>
#include <iostream>
#include "Cliente.h"
#include "Celular.h"
#include "Date.h"

using namespace std;

class Plano{
protected:
    string _nomePlano;
    double _ValorMin;
    double _Velocidade;
    double _Franquia;
    double _VelocAlem;
public:
    Plano();
    Plano(string nomePlano, double ValorMin, double Velocidade, double franquia, double VelocAlem);
    ~Plano();
    virtual string set_NomeDoPlano();//Fun��o para cadastrar o nome do plano do cliente.
    double set_ValoresDoPlano(); //Cadastra os valores do plano.

};

class PrePago:public Plano{
private:
    double _credito;
    Date _validade;
public:
    PrePago();
    PrePago(string nomePlano, double credito);
    ~PrePago();
    double get_credito();
    void get_validade();
    string set_NomeDoPlano();
    void add_credito();
};

class PosPago:public Plano{
public:
    Date _vencimento;
    PosPago();
    PosPago(string _nomePlano, Date vencimento);
    ~PosPago();
    Date get_vencimento();
    string set_NomeDoPlano();
};

#endif // _PLANO_H

