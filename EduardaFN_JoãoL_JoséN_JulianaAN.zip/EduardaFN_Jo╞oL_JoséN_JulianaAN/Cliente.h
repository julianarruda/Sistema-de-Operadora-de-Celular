#ifndef _CLIENTE_H
#define _CLIENTE_H

#include <string>
#include <iostream>
#include <vector>
#include "Celular.h"
#include "Plano.h"
#include "Liga��o.h"
#include "Celular.h"

using namespace std;

class Cliente{  //A classe cliente definir� os dados dos clientes cadastrados.
private:
    string _nome;
    string _CPF_CNPJ;
    string _endereco;
    vector<Celular> C;
public:
    Cliente();
    Cliente(string nome, string CPF_CNPJ, string endereco);
    ~Cliente();
    string get_nome();
    string get_CPF();
    string get_endereco();
    string Dados_Cliente();//Fun��o para coletar os dados do cliente a cadastrar.
    void Ver_Dados();//Permite ver os dados do clinte cadastrado.
};
#endif // _CLIENTE_H
