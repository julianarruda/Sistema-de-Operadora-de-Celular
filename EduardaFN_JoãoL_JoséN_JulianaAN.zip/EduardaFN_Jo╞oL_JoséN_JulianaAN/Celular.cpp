#include "Celular.h"

Celular::Celular(){
}
Celular::Celular(double numero, Plano plano){
    _numero = numero;
    _plano = plano;
}

Celular:: ~Celular(){
    cout<< "deletando Celular" << endl;
}
double Celular:: get_numero(){
    return this->_numero;
}

void Celular:: set_numero(int num){
    _numero=num;
}

void Celular::set_plano(){
    cout<< "Digite o plano do cliente: "<< endl;
    string temp;
    cin >> temp;
    this->_plano = Plano(temp);
}
static int Celular::proxNumCelular(){
    int j=0;
    int aux=90000000+j;
    j++;
    return aux;
}
