#include "Liga��o.h"

Ligacao::Ligacao(){
}
Ligacao::~Ligacao(){
}
Ligacao::Ligacao(Date datahora, double duracao, double custo){
    _datahora = datahora;
    _duracao = duracao;
     _custo = custo;
     _custo = 0.50;
}
void Ligacao::get_dataHora(){
    return this->_datahora;
}
double Ligacao::get_Duracao(){
    return this->_duracao;
}
void get_custo(){
    return this->_custo;
}

LigacaoDados::LigacaoDados{
}
LigacaoDados::~LigacaoDados{
}
LigacaoDados::LigacaoDados(TiposDados DW, TipoDados UP){
    DW = download;
    UP = upload;
}
int get_download(){
    return this->_download;
}
int get_upload(){
    return this->_upload;
}
void Ligacao::registro_ligacao(){
    cout<<"Entre com a Data e a hora da liga��o: "<<endl;
    cin>>_datahora;
    cout<<"Duracao da ligacao: "<<endl;
    cin<<_duracao;
    cout<< "    Registro ligacao:"<<endl;
    cout<<"Data: "<<_datahora<<endl;
    cout<<"Duracao: "<<_duracao<<endl;
}

LigacaoSimples::LigacaoSimples(){
}
LigacaoSimples::~LigacaoSimples(){
}
LigacaoSimples::LigacaoSimples(double numTelefone){
    _numTelefone = numTelefone;
}
double get_numTelefone(){
    return this->_numTelefone;
}
