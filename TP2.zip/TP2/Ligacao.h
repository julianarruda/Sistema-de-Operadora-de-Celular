#ifndef LIGACAO_H_
#define LIGACAO_H_
#include "Celular.h"
#include "Date.h"

#include <string>
#include <iostream>
#define MAX 1000
using namespace std;

class Ligacao{
protected:
    Date _datahora;
    double _duracao;
    double _custo;
public:
    Ligacao();
    ~Ligacao();
    Ligacao(Date datahora, double duracao, double custo);
    void get_dataHora();
    double get_Duracao();
    void get_custo();
    void registro_ligacao(); //Extrato de liga��o do cliente.

};

class LigacaoDados: public Ligacao{
private:
    enum TipoDados {download,upload};
public:
    TipoDados DW, UP;
    LigacaoDados();
    ~LigacaoDados();
    LigacaoDados(TipoDados DW, TipoDados UP);
    int get_download();
    int get_upload();
    void set_TipoDados();
    void registro_ligacao();
};

class LigacaoSimples: public Ligacao{
private:
    double _numTelefone;
public:
    LigacaoSimples();
    ~LigacaoSimples();
    LigacaoSimples(double numTelefone);
    double get_numTelefone();
    void registro_ligacao();
};
#endif // LIGACAO_H_

